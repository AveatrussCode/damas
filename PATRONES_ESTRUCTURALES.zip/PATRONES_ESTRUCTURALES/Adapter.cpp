#include <iostream>
#include <cmath>
using namespace std;
class PiezaRedonda{
    private:
        int radio;
    public:
        PiezaRedonda(int radio){
            this->radio=radio;
        }
        int getRadio(){
            return radio;
        }
};

class HoyoRedondo{
    private:
        int radio;
    public:
        HoyoRedondo(int radio){
            this->radio=radio;
        }
        int getRadio(){
            return radio;
        }
        bool seAdapta(PiezaRedonda pieza){
            return this->getRadio() >= pieza.getRadio();
        }
};

class PiezaCuadrada{
    private:
        int lado;
    public:
        PiezaCuadrada(int lado){
            this->lado=lado;
        }
        int getLado(){
            return lado;
        }
};

class PiezaCuadradaAdaptador: public PiezaRedonda{
    private:
        PiezaCuadrada *pieza;
    public:
        PiezaCuadradaAdaptador(PiezaCuadrada *pieza):PiezaRedonda(pieza->getLado()*sqrt(2)/2){
            this->pieza=pieza;
        }
        int getRadio(){
            return pieza->getLado()*sqrt(2)/2;
    
        }
};
int main(){
    HoyoRedondo hoyo(5);
    PiezaRedonda rpieza(5);
    if (hoyo.seAdapta(rpieza)) cout << "verdadero" << endl;
    else cout << "falso" << endl;

    PiezaCuadrada cpieza_small(5);
    PiezaCuadrada cpieza_big(10);

   //if (hoyo.seAdapta(cpieza_small)) cout << "verdadero" << endl; // no compila (son incompatibles)
    //else cout << "falso" << endl;

    PiezaCuadradaAdaptador cpieza_small_adaptador(&cpieza_small);
    PiezaCuadradaAdaptador cpieza_big_adaptador(&cpieza_big);

    cout << "Se adapta? " << (hoyo.seAdapta(cpieza_small_adaptador)? "Si": "No") << endl;
    cout << "Se adapta? " << (hoyo.seAdapta(cpieza_big_adaptador)? "Si": "No") << endl;

    return 0;
}