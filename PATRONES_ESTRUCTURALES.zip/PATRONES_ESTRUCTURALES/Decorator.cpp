#include <iostream>
#include <string>
using namespace std;

// Interfaz FuenteDeDatos
class FuenteDeDatos {
public:
    virtual void escribirDatos(const string& datos) = 0;
    virtual string leerDatos() = 0;
    virtual ~FuenteDeDatos() = default;
};

// Componente Concreto: FuenteDeDatosArchivo
class FuenteDeDatosArchivo : public FuenteDeDatos {
private:
    string nombreArchivo;
    string almacenamiento;

public:
    FuenteDeDatosArchivo(const string& nombreArchivo) : nombreArchivo(nombreArchivo) {}

    void escribirDatos(const string& datos) override {
        almacenamiento = datos;
        cout << "Escribiendo datos en el archivo: " << nombreArchivo << endl;
    }

    string leerDatos() override {
        cout << "Leyendo datos del archivo: " << nombreArchivo << endl;
        return almacenamiento;
    }
};

// Clase Decoradora Base
class DecoradorFuenteDeDatos : public FuenteDeDatos {
protected:
    FuenteDeDatos* fuente;

public:
    DecoradorFuenteDeDatos(FuenteDeDatos* fuente) : fuente(fuente) {}

    void escribirDatos(const string& datos) override {
        fuente->escribirDatos(datos);
    }

    string leerDatos() override {
        return fuente->leerDatos();
    }

    virtual ~DecoradorFuenteDeDatos() {
        delete fuente;
    }
};

// Decorador Concreto: DecoradorEncriptacion
class DecoradorEncriptacion : public DecoradorFuenteDeDatos {
public:
    DecoradorEncriptacion(FuenteDeDatos* fuente) : DecoradorFuenteDeDatos(fuente) {}

    void escribirDatos(const string& datos) override {
        string datosEncriptados = encriptar(datos);
        cout << "Encriptando datos...\n";
        DecoradorFuenteDeDatos::escribirDatos(datosEncriptados);
    }

    string leerDatos() override {
        string datosEncriptados = DecoradorFuenteDeDatos::leerDatos();
        cout << "Desencriptando datos...\n";
        return desencriptar(datosEncriptados);
    }

private:
    string encriptar(const string& datos) {
        string resultado = datos;
        for (char& c : resultado) {
            c += 1; // Ejemplo simple: desplaza cada carácter al siguiente.
        }
        return resultado;
    }

    string desencriptar(const string& datos) {
        string resultado = datos;
        for (char& c : resultado) {
            c -= 1; // Ejemplo simple: revierte el desplazamiento.
        }
        return resultado;
    }
};

// Decorador Concreto: DecoradorCompresion
class DecoradorCompresion : public DecoradorFuenteDeDatos {
public:
    DecoradorCompresion(FuenteDeDatos* fuente) : DecoradorFuenteDeDatos(fuente) {}

    void escribirDatos(const string& datos) override {
        string datosComprimidos = comprimir(datos);
        cout << "Comprimiendo datos...\n";
        DecoradorFuenteDeDatos::escribirDatos(datosComprimidos);
    }

    string leerDatos() override {
        string datosComprimidos = DecoradorFuenteDeDatos::leerDatos();
        cout << "Descomprimiendo datos...\n";
        return descomprimir(datosComprimidos);
    }

private:
    string comprimir(const string& datos) {
        return "COMPRIMIDO[" + datos + "]"; // Simulación de compresión.
    }

    string descomprimir(const string& datos) {
        if (datos.find("COMPRIMIDO[") == 0) {
            return datos.substr(11, datos.length() - 12); // Simulación de descompresión.
        }
        return datos;
    }
};

// Ejemplo sencillo
void ejemploBasico() {
    FuenteDeDatos* fuente = new FuenteDeDatosArchivo("archivo.dat");
    fuente->escribirDatos("Datos originales");

    fuente = new DecoradorCompresion(fuente);
    fuente->escribirDatos("Datos originales");

    fuente = new DecoradorEncriptacion(fuente);
    fuente->escribirDatos("Datos originales");

    cout << "Datos finales: " << fuente->leerDatos() << endl;

    delete fuente;
}

// Código cliente con decoradores configurables
class GestorDeSalarios {
private:
    FuenteDeDatos* fuente;

public:
    GestorDeSalarios(FuenteDeDatos* fuente) : fuente(fuente) {}

    string cargar() {
        return fuente->leerDatos();
    }

    void guardar(const string& datos) {
        fuente->escribirDatos(datos);
    }
};

// Configurador de la aplicación
void configuradorAplicacion(bool encriptar, bool comprimir) {
    FuenteDeDatos* fuente = new FuenteDeDatosArchivo("salarios.dat");

    if (encriptar) {
        fuente = new DecoradorEncriptacion(fuente);
    }
    if (comprimir) {
        fuente = new DecoradorCompresion(fuente);
    }

    GestorDeSalarios gestor(fuente);
    gestor.guardar("Registros de salarios");
    cout << "Datos cargados: " << gestor.cargar() << endl;

    delete fuente;
}

int main() {
    cout << "Ejemplo Básico:\n";
    ejemploBasico();

    cout << "\nConfiguración de la Aplicación:\n";
    configuradorAplicacion(true, true);

    return 0;
}
