#include <iostream>

using namespace std;

// Interfaz Componente (Gráfico)
class Grafico {
public:
    virtual void mover(int x, int y) = 0;
    virtual void dibujar() const = 0;
    virtual ~Grafico() = default;
};

// Clase Hoja: Punto
class Punto : public Grafico {
protected:
    int x, y;

public:
    Punto(int x, int y) : x(x), y(y) {}

    void mover(int dx, int dy) override {
        x += dx;
        y += dy;
    }

    void dibujar() const override {
        cout << "Dibujar un punto en (" << x << ", " << y << ")" << endl;
    }
};

// Clase Hoja Extendida: Círculo
class Circulo : public Punto {
private:
    int radio;

public:
    Circulo(int x, int y, int radio) : Punto(x, y), radio(radio) {}

    void dibujar() const override {
        cout << "Dibujar un círculo en (" << x << ", " << y << ") con radio " << radio << endl;
    }
};

// Clase Compuesta: CompuestoGráfico
class CompuestoGrafico : public Grafico {
private:
    Grafico* hijos[10];  
    int contador;       

public:
    CompuestoGrafico() : contador(0) {}

    void agregar(Grafico* hijo) {
        if (contador < 10) {
            hijos[contador++] = hijo;
        } else {
            cout << "No se pueden agregar más hijos, límite alcanzado." << endl;
        }
    }

    void eliminar(Grafico* hijo) {
        for (int i = 0; i < contador; ++i) {
            if (hijos[i] == hijo) {
                for (int j = i; j < contador - 1; ++j) {
                    hijos[j] = hijos[j + 1];
                }
                hijos[--contador] = nullptr;
                return;
            }
        }
        cout << "Hijo no encontrado." << endl;
    }

    void mover(int dx, int dy) override {
        for (int i = 0; i < contador; ++i) {
            hijos[i]->mover(dx, dy);
        }
    }

    void dibujar() const override {
        cout << "Dibujar un grupo de gráficos:" << endl;
        for (int i = 0; i < contador; ++i) {
            hijos[i]->dibujar();
        }
        cout << "Fin del grupo de gráficos." << endl;
    }
};

// Clase Cliente: Editor de Imágenes
class EditorDeImagenes {
private:
    CompuestoGrafico todo;

public:
    void cargar() {
        todo.agregar(new Punto(1, 2));
        todo.agregar(new Circulo(5, 3, 10));
    }

    void agruparSeleccionados(Grafico* componentes[], int tamanio) {
        CompuestoGrafico* grupo = new CompuestoGrafico();
        for (int i = 0; i < tamanio; ++i) {
            grupo->agregar(componentes[i]);
            todo.eliminar(componentes[i]);
        }
        todo.agregar(grupo);
        todo.dibujar();
    }

    void dibujarTodo() const {
        todo.dibujar();
    }
};

// Código Cliente
int main() {
    EditorDeImagenes editor;

    // Cargar los gráficos
    editor.cargar();
    cout << "Dibujar todos los componentes cargados:" << endl;
    editor.dibujarTodo();

    // Seleccionar componentes específicos y agruparlos
    Grafico* componentesSeleccionados[2];
    componentesSeleccionados[0] = new Punto(1, 2);
    componentesSeleccionados[1] = new Circulo(5, 3, 10);

    cout << "\nAgrupar componentes seleccionados:" << endl;
    editor.agruparSeleccionados(componentesSeleccionados, 2);

    return 0;
}
