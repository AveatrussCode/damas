#include <iostream>
#include <string>
using namespace std;

// Interfaz del servicio remoto
class BibliotecaYouTubeTerceros {
public:
    virtual string listarVideos() = 0;
    virtual string obtenerInfoVideo(const string& id) = 0;
    virtual void descargarVideo(const string& id) = 0;
    virtual ~BibliotecaYouTubeTerceros() = default;
};

// Clase concreta que interactúa con el servicio real de YouTube
class ClaseYouTubeTerceros : public BibliotecaYouTubeTerceros {
public:
    string listarVideos() override {
        cout << "Solicitando lista de videos de YouTube...\n";
        return "Lista de videos de YouTube";
    }

    string obtenerInfoVideo(const string& id) override {
        cout << "Obteniendo información del video: " << id << " de YouTube...\n";
        return "Información del video " + id;
    }

    void descargarVideo(const string& id) override {
        cout << "Descargando video: " << id << " de YouTube...\n";
    }
};

// Clase Proxy con almacenamiento en caché (sin unordered_map)
class ClaseYouTubeCache : public BibliotecaYouTubeTerceros {
private:
    BibliotecaYouTubeTerceros* servicio;
    string cacheListaVideos;

    static const int MAX_CACHE = 100; // Tamaño máximo del caché
    string cacheIDs[MAX_CACHE];      // IDs de los videos en caché
    string cacheVideos[MAX_CACHE];   // Información de los videos en caché
    int cacheSize;                   // Cantidad actual de videos en caché
    bool necesitaActualizar;

    int buscarEnCache(const string& id) {
        for (int i = 0; i < cacheSize; ++i) {
            if (cacheIDs[i] == id) {
                return i; // Retorna el índice si encuentra el video
            }
        }
        return -1; // No encontrado
    }

public:
    ClaseYouTubeCache(BibliotecaYouTubeTerceros* servicio)
        : servicio(servicio), cacheSize(0), necesitaActualizar(false) {}

    string listarVideos() override {
        if (cacheListaVideos.empty() || necesitaActualizar) {
            cacheListaVideos = servicio->listarVideos();
        }
        return cacheListaVideos;
    }

    string obtenerInfoVideo(const string& id) override {
        int indice = buscarEnCache(id);
        if (indice == -1 || necesitaActualizar) {
            if (cacheSize < MAX_CACHE) {
                cacheIDs[cacheSize] = id;
                cacheVideos[cacheSize] = servicio->obtenerInfoVideo(id);
                ++cacheSize;
            } else {
                cout << "Error: Caché de videos lleno.\n";
                return servicio->obtenerInfoVideo(id); // Solicitud directa si el caché está lleno
            }
        }
        return cacheVideos[buscarEnCache(id)];
    }

    void descargarVideo(const string& id) override {
        if (necesitaActualizar) {
            cout << "Actualizando caché antes de descargar el video...\n";
        }
        servicio->descargarVideo(id);
    }

    void resetCache() {
        cacheListaVideos.clear();
        cacheSize = 0;
        necesitaActualizar = true;
    }
};

// Clase de gestión de YouTube (Cliente)
class GestorYouTube {
private:
    BibliotecaYouTubeTerceros* servicio;

public:
    GestorYouTube(BibliotecaYouTubeTerceros* servicio) : servicio(servicio) {}

    void renderizarPaginaVideo(const string& id) {
        string info = servicio->obtenerInfoVideo(id);
        cout << "Renderizando página del video: " << info << "\n";
    }

    void renderizarListaVideos() {
        string lista = servicio->listarVideos();
        cout << "Renderizando lista de videos: " << lista << "\n";
    }

    void reaccionarEntradaUsuario(const string& id) {
        renderizarPaginaVideo(id);
        renderizarListaVideos();
    }
};

class Aplicacion {
public:
    void iniciar() {
        ClaseYouTubeTerceros* servicioReal = new ClaseYouTubeTerceros();
        ClaseYouTubeCache* proxyCache = new ClaseYouTubeCache(servicioReal);
        GestorYouTube* gestor = new GestorYouTube(proxyCache);

        gestor->reaccionarEntradaUsuario("12345");
        gestor->reaccionarEntradaUsuario("12345"); // Utiliza la caché
        gestor->reaccionarEntradaUsuario("67890");

        delete gestor;
        delete proxyCache;
        delete servicioReal;
    }
};

int main() {
    Aplicacion app;
    app.iniciar();
    return 0;
}
