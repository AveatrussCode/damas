#include <iostream>
#include <string>
using namespace std;

// Clase Flyweight: Tipo de Árbol
class TipoArbol {
private:
    string nombre;
    string color;
    string textura;

public:
    TipoArbol(const string& nombre, const string& color, const string& textura)
        : nombre(nombre), color(color), textura(textura) {}

    string obtenerClave() const {
        return nombre + "_" + color + "_" + textura;
    }

    void dibujar(const string& canvas, int x, int y) const {
        cout << "Dibujando un árbol [" << nombre << ", " << color << ", " << textura
             << "] en el canvas " << canvas << " en las coordenadas (" << x << ", " << y << ").\n";
    }
};

// Fábrica Flyweight: Maneja los objetos TipoArbol
class FabricaArboles {
private:
    static const int MAX_TIPOS = 100;
    TipoArbol* tiposArboles[MAX_TIPOS];
    int cantidadTipos;

public:
    FabricaArboles() : cantidadTipos(0) {
        for (int i = 0; i < MAX_TIPOS; ++i) {
            tiposArboles[i] = nullptr;
        }
    }

    TipoArbol* obtenerTipoArbol(const string& nombre, const string& color, const string& textura) {
        string claveBuscada = nombre + "_" + color + "_" + textura;

        for (int i = 0; i < cantidadTipos; ++i) {
            if (tiposArboles[i] && tiposArboles[i]->obtenerClave() == claveBuscada) {
                return tiposArboles[i];
            }
        }

        if (cantidadTipos < MAX_TIPOS) {
            cout << "Creando un nuevo tipo de árbol: " << claveBuscada << endl;
            tiposArboles[cantidadTipos] = new TipoArbol(nombre, color, textura);
            return tiposArboles[cantidadTipos++];
        }

        cout << "Error: No se pueden crear más tipos de árboles, límite alcanzado.\n";
        return nullptr;
    }

    ~FabricaArboles() {
        for (int i = 0; i < cantidadTipos; ++i) {
            delete tiposArboles[i];
        }
    }
};

// Clase Contextual: Árbol
class Arbol {
private:
    int x, y;
    TipoArbol* tipo;

public:
    Arbol() : x(0), y(0), tipo(nullptr) {}

    void inicializar(int x, int y, TipoArbol* tipo) {
        this->x = x;
        this->y = y;
        this->tipo = tipo;
    }

    void dibujar(const string& canvas) const {
        if (tipo) {
            tipo->dibujar(canvas, x, y);
        } else {
            cout << "Error: Árbol no inicializado.\n";
        }
    }
};

// Cliente: Bosque
class Bosque {
private:
    static const int MAX_ARBOLES = 1000;
    Arbol arboles[MAX_ARBOLES];
    int cantidadArboles;
    FabricaArboles fabrica;

public:
    Bosque() : cantidadArboles(0) {}

    void plantarArbol(int x, int y, const string& nombre, const string& color, const string& textura) {
        if (cantidadArboles < MAX_ARBOLES) {
            TipoArbol* tipo = fabrica.obtenerTipoArbol(nombre, color, textura);
            if (tipo) {
                arboles[cantidadArboles].inicializar(x, y, tipo);
                ++cantidadArboles;
            }
        } else {
            cout << "Error: No se pueden plantar más árboles, límite alcanzado.\n";
        }
    }

    void dibujar(const string& canvas) const {
        for (int i = 0; i < cantidadArboles; ++i) {
            arboles[i].dibujar(canvas);
        }
    }
};

// Función Principal
int main() {
    Bosque bosque;

    bosque.plantarArbol(10, 20, "Roble", "Verde", "TexturaRoble");
    bosque.plantarArbol(30, 40, "Pino", "VerdeOscuro", "TexturaPino");
    bosque.plantarArbol(50, 60, "Roble", "Verde", "TexturaRoble"); // Reutiliza el flyweight

    cout << "\nDibujando el bosque:\n";
    bosque.dibujar("Canvas1");

    return 0;
}
