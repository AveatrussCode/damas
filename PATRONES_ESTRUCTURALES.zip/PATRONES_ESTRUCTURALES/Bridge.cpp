#include <iostream>
using namespace std;
// Implementación
class Dispositivo{
    private:
        int volumen=50;
        int canal=1;
        bool activo=false;

    public:
        bool estaActivado(){
            return activo==true;
        }
        void activar(){
            activo=true;
        }
        void desactivar(){
            activo=false;
        }
        int getVolumen(){
            return volumen;
        }
        void setVolumen(int porcentaje){
            volumen=porcentaje;
        }
        int getCanal(){
            return canal;
        }
        void setCanal(int canal){
            this->canal=canal;
        }
};
//Abstracción
class ControlRemoto{
    protected:
        Dispositivo *dispositivo;
    public:
        ControlRemoto(Dispositivo *dispositivo){
            this->dispositivo=dispositivo;
        }
        void alternarEnergia(){
            if(dispositivo->estaActivado()){
                dispositivo->desactivar();
            }
            else {
                dispositivo->activar();
            }
        }
        void bajarVolumen(){
            dispositivo->setVolumen(dispositivo->getVolumen()-10);
        }
        void subirVolumen(){
            dispositivo->setVolumen(dispositivo->getVolumen()+10);
        }
        void bajarCanal(){
            dispositivo->setCanal(dispositivo->getCanal()-1);
        }
        void subirCanal(){
            dispositivo->setCanal(dispositivo->getCanal()+1);
        }
};
class ControlRemotoAvanzado: public ControlRemoto{
    public:
        void mutear(){
            dispositivo->setVolumen(0);
        }
};
class Tv: public Dispositivo{
    continue;
};
class Radio: public Dispositivo{
    continue;
};
